# Instructions

1. Update all credentials and API keys in the Credentials file.

2. To change the list of websites to collect cookies, edit the `WEBSTIES` string in `cookie_robot.py`.

3. To run the bot, simply execute the `main.py` file.
