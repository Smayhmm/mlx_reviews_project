API_GPT = "ChatGPT PASSWORD"
MLX_EMAIL = "MLX EMAIL"
MLX_PASSWORD = "MLX PASSWORD"
API_KEY = "SMS POOL API TOKEN" # SMS Pool
AUTOMATION_TOKEN = "MLX API TOKEN"
FOLDER_ID = "MLX FOLDER/WORKSPACE ID"
REVIEW_LINK = "Google Maps link for the review"
REVIEW_DESCRIPTION = "What you want to review: Give me a short review for a japonese restaurant"